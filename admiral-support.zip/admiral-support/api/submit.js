// api/submit.js — Vercel Serverless (Node.js)
// Receives POST { type: "support" | "game_suggestion", data: {...} }
// Appends { id, type, data, time } to a JSONBin bin and (optionally)
// sends a notification to a Rubika bot.

const BIN_ID = process.env.JSONBIN_BIN_ID;
const MASTER_KEY = process.env.JSONBIN_MASTER_KEY;

const RUBIKA_BOT_TOKEN = process.env.RUBIKA_BOT_TOKEN;
const RUBIKA_CHAT_ID = process.env.RUBIKA_CHAT_ID;

async function getRecords() {
  const r = await fetch(`https://api.jsonbin.io/v3/b/${BIN_ID}/latest`, {
    headers: { "X-Master-Key": MASTER_KEY },
  });
  if (!r.ok) throw new Error("JSONBin read failed: " + r.status);
  const j = await r.json();
  return Array.isArray(j.record) ? j.record : [];
}

async function putRecords(records) {
  const r = await fetch(`https://api.jsonbin.io/v3/b/${BIN_ID}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json", "X-Master-Key": MASTER_KEY },
    body: JSON.stringify(records),
  });
  if (!r.ok) throw new Error("JSONBin write failed: " + r.status);
}

async function sendToRubika(text) {
  if (!RUBIKA_BOT_TOKEN || !RUBIKA_CHAT_ID) return;
  try {
    await fetch(`https://botapi.rubika.ir/v3/${RUBIKA_BOT_TOKEN}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: RUBIKA_CHAT_ID, text }),
    });
  } catch (e) {
    console.error("Rubika send failed:", e);
  }
}

module.exports = async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST")
    return res.status(405).json({ ok: false, error: "Method not allowed" });

  try {
    let body = req.body;
    if (typeof body === "string") body = JSON.parse(body || "{}");
    const { type, data } = body || {};

    if (!data || !["support", "game_suggestion"].includes(type)) {
      return res.status(400).json({ ok: false, error: "Invalid payload" });
    }

    if (type === "support") {
      const { name, category, message } = data;
      if (!name || !message || String(message).trim().length < 10) {
        return res
          .status(400)
          .json({ ok: false, error: "Message must be at least 10 characters" });
      }
    }

    const records = await getRecords();
    const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
    const time = Date.now();
    records.push({ id, type, data, time });
    await putRecords(records);

    const t = new Date(time).toLocaleString("fa-IR");
    if (type === "support") {
      await sendToRubika(
        `📨 پشتیبانی جدید (admiralsitca)\n👤 ${data.name}\n🗂 ${data.category}\n💬 ${data.message}\n🕐 ${t}\n#${id}`
      );
    } else {
      const d = data;
      await sendToRubika(
        `🎮 پیشنهاد بازی (admiralsitca)\n🕹 ${d.name}\n💻 ${(d.platforms || []).join(", ")}\n⭐ ${d.rating}/10\n` +
          `فارسی‌ساز: ${d.farsiPatch ? "✅" : "—"} | چندنفره: ${d.multiplayer ? "✅" : "—"} | سیستم ضعیف: ${d.lowSpec ? "✅" : "—"}\n` +
          `📝 ${d.description}\n🕐 ${t}\n#${id}`
      );
    }

    return res.status(200).json({ ok: true, id });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ ok: false, error: "Server error" });
  }
};
