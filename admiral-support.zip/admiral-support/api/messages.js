// api/messages.js — Vercel Serverless (Node.js)
// GET    /api/messages?key=ADMIN_KEY        -> all records
// DELETE /api/messages?key=ADMIN_KEY&id=ID -> remove one record

const BIN_ID = process.env.JSONBIN_BIN_ID;
const MASTER_KEY = process.env.JSONBIN_MASTER_KEY;
const ADMIN_KEY = process.env.ADMIN_KEY;

async function getRecords() {
  const r = await fetch(`https://api.jsonbin.io/v3/b/${BIN_ID}/latest`, {
    headers: { "X-Master-Key": MASTER_KEY },
  });
  if (!r.ok) throw new Error("JSONBin read failed: " + r.status);
  const j = await r.json();
  return Array.isArray(j.record) ? j.record : [];
}

async function putRecords(records) {
  const r = await fetch(`https://api.jsonbin.io/v3/b/${BIN_ID}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json", "X-Master-Key": MASTER_KEY },
    body: JSON.stringify(records),
  });
  if (!r.ok) throw new Error("JSONBin write failed: " + r.status);
}

module.exports = async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,DELETE,OPTIONS");
  if (req.method === "OPTIONS") return res.status(204).end();

  const key = req.query.key;
  if (!key || key !== ADMIN_KEY) {
    return res.status(401).json({ ok: false, error: "Unauthorized" });
  }

  try {
    if (req.method === "GET") {
      const records = await getRecords();
      return res.status(200).json(records);
    }
    if (req.method === "DELETE") {
      const id = req.query.id;
      const records = await getRecords();
      const next = records.filter((m) => m.id !== id);
      if (next.length === records.length) {
        return res.status(404).json({ ok: false, error: "Not found" });
      }
      await putRecords(next);
      return res.status(200).json({ ok: true, deleted: id });
    }
    return res.status(405).json({ ok: false, error: "Method not allowed" });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ ok: false, error: "Server error" });
  }
};
